console.log('Primera Frase')
setTimeout(function() {
    console.log('Segunda Frase')
}, 1000)
setTimeout(function() {
    console.log('Segunda Frase - II Parte')
}, 0)
console.log('Tercera Frase')
console.log('Cuarta Frase')
console.log('Quinta Frase')



// function hola(nombre, fn_cb) {
//     setTimeout() {
        
//     }
// }

// console.log( 'Inicializando una conversación.' )

// hola('Guillermo', function(nombre) {
//     dialogar(nombre, 4)
// })

// console.log( 'Finalizando la conversación...' )