// Funcion Declarativa

function imprimirResultado() {
    return 'Hola mundo'
}

// Función de Expresión, también conocidas como anónimas.

var suma = function(a, b) {
    return (a + b)
}

// Función flecha

var suma2 = (a, b) => a+b

var suma3 = (a, b) => {
    c = a+b
    return c
}
