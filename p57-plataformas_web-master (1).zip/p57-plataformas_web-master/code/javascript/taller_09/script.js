var vscode = 'Visual Studio Code'

function imprimirVSCode() {
    console.log( `${vscode}` )
}

imprimirVSCode()

console.log( `${vscode}` )