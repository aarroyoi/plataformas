console.log( `${vscode}` )
console.log( `Segunda impresión: ${vscode}` )
