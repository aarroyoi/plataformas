let saludo = process.env.NOMBRE || 'Sin Nombre'

console.log(`Hola ${saludo}`)